package za.ac.tut.kotashop.servlets;

import za.ac.tut.kotashop.dao.RatingDAO;
import za.ac.tut.kotashop.model.Rating;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RatingServlet extends HttpServlet {
    private RatingDAO ratingDAO = new RatingDAO();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String productIdStr = request.getParameter("productId");
        String customerName = request.getParameter("customerName");
        String customerEmail = request.getParameter("customerEmail");
        String ratingValueStr = request.getParameter("ratingValue");
        String reviewText = request.getParameter("reviewText");
        
        Integer productId = null;
        if (productIdStr != null && !productIdStr.isEmpty()) {
            productId = Integer.parseInt(productIdStr);
        }
        int ratingValue = Integer.parseInt(ratingValueStr);
        
        Rating rating = new Rating();
        rating.setProductId(productId);
        rating.setCustomerName(customerName);
        rating.setCustomerEmail(customerEmail);
        rating.setRatingValue(ratingValue);
        rating.setReviewText(reviewText);
        
        boolean saved = ratingDAO.saveRating(rating);
        
        if (saved) {
            request.setAttribute("success", "Thank you for your rating and review!");
        } else {
            request.setAttribute("error", "Failed to submit rating. Please try again.");
        }
        
        if (productId != null) {
            response.sendRedirect(request.getContextPath() + "/menu?productId=" + productId);
        } else {
            request.getRequestDispatcher("/pages/rate-us.jsp").forward(request, response);
        }
    }
}