package za.ac.tut.kotashop.servlets;

import za.ac.tut.kotashop.dao.ProductDAO;
import za.ac.tut.kotashop.model.Product;
import za.ac.tut.kotashop.model.CartItem;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CartServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAO();
    
    @Override
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        
        if (cart == null) {
            cart = new ArrayList<>();
            session.setAttribute("cart", cart);
        }
        
        String action = request.getParameter("action");
        
        if ("add".equals(action)) {
            String productIdStr = request.getParameter("productId");
            String quantityStr = request.getParameter("quantity");
            
            if (productIdStr != null && quantityStr != null) {
                int productId = Integer.parseInt(productIdStr);
                int quantity = Integer.parseInt(quantityStr);
                Product product = productDAO.getProductById(productId);
                
                if (product != null) {
                    boolean found = false;
                    for (CartItem item : cart) {
                        if (item.getProduct().getProductId() == productId) {
                            item.setQuantity(item.getQuantity() + quantity);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        cart.add(new CartItem(product, quantity));
                    }
                }
            }
            // Redirect back to the page that sent the request
            String referer = request.getHeader("referer");
            if (referer != null && !referer.isEmpty()) {
                response.sendRedirect(referer);
            } else {
                response.sendRedirect(request.getContextPath() + "/MenuServlet");
            }
            
        } else if ("update".equals(action)) {
            int productId = Integer.parseInt(request.getParameter("productId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            
            for (int i = 0; i < cart.size(); i++) {
                if (cart.get(i).getProduct().getProductId() == productId) {
                    if (quantity <= 0) {
                        cart.remove(i);
                    } else {
                        cart.get(i).setQuantity(quantity);
                    }
                    break;
                }
            }
            response.sendRedirect(request.getContextPath() + "/CartServlet");
            
        } else if ("remove".equals(action)) {
            int productId = Integer.parseInt(request.getParameter("productId"));
            cart.removeIf(item -> item.getProduct().getProductId() == productId);
            response.sendRedirect(request.getContextPath() + "/CartServlet");
        } else {
            response.sendRedirect(request.getContextPath() + "/CartServlet");
        }
        
        session.setAttribute("cart", cart);
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Forward to cart page
        request.getRequestDispatcher("/pages/cart.jsp").forward(request, response);
    }
}