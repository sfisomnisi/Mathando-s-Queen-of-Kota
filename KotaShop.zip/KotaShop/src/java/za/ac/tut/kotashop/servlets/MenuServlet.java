package za.ac.tut.kotashop.servlets;

import za.ac.tut.kotashop.dao.ProductDAO;
import za.ac.tut.kotashop.model.Category;
import za.ac.tut.kotashop.model.Product;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MenuServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String categoryIdParam = request.getParameter("categoryId");
        List<Product> products;
        List<Category> categories = productDAO.getAllCategories();
        
        if (categoryIdParam != null && !categoryIdParam.isEmpty()) {
            int categoryId = Integer.parseInt(categoryIdParam);
            products = productDAO.getProductsByCategory(categoryId);
            request.setAttribute("selectedCategoryId", categoryId);
        } else {
            products = productDAO.getAllProducts();
            request.setAttribute("selectedCategoryId", 0);
        }
        
        request.setAttribute("products", products);
        request.setAttribute("categories", categories);
        request.getRequestDispatcher("/pages/menu.jsp").forward(request, response);
    }
}