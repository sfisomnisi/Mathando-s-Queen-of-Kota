package za.ac.tut.kotashop.servlets;

import za.ac.tut.kotashop.dao.ProductDAO;
import za.ac.tut.kotashop.model.Product;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HomeServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<Product> featuredProducts = productDAO.getAllProducts();
        if (featuredProducts.size() > 8) {
            featuredProducts = featuredProducts.subList(0, 8);
        }
        request.setAttribute("featuredProducts", featuredProducts);
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}