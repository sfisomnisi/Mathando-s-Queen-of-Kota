package za.ac.tut.kotashop.dao;

import za.ac.tut.kotashop.model.CartItem;
import za.ac.tut.kotashop.model.Order;
import java.sql.*;
import java.util.List;
import java.util.UUID;

public class OrderDAO {
    
    public int saveOrder(Order order, List<CartItem> cart) {
        String orderSql = "INSERT INTO orders (order_number, customer_name, customer_email, " +
                         "customer_phone, delivery_address, special_instructions, subtotal, delivery_fee, total_amount, payment_method) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String itemSql = "INSERT INTO order_items (order_id, product_name, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)";
        int orderId = -1;
        
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            
            String orderNumber = "ORD-" + System.currentTimeMillis() + "-" + UUID.randomUUID().toString().substring(0, 5).toUpperCase();
            order.setOrderNumber(orderNumber);
            
            try (PreparedStatement pstmt = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, order.getOrderNumber());
                pstmt.setString(2, order.getCustomerName());
                pstmt.setString(3, order.getCustomerEmail());
                pstmt.setString(4, order.getCustomerPhone());
                pstmt.setString(5, order.getDeliveryAddress());
                pstmt.setString(6, order.getSpecialInstructions());
                pstmt.setDouble(7, order.getSubtotal());
                pstmt.setDouble(8, order.getDeliveryFee());
                pstmt.setDouble(9, order.getTotalAmount());
                pstmt.setString(10, order.getPaymentMethod());
                pstmt.executeUpdate();
                
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    orderId = rs.getInt(1);
                }
            }
            
            if (orderId > 0) {
                try (PreparedStatement pstmt = conn.prepareStatement(itemSql)) {
                    for (CartItem item : cart) {
                        pstmt.setInt(1, orderId);
                        pstmt.setString(2, item.getProduct().getProductName());
                        pstmt.setInt(3, item.getQuantity());
                        pstmt.setDouble(4, item.getProduct().getPrice());
                        pstmt.setDouble(5, item.getSubtotal());
                        pstmt.addBatch();
                    }
                    pstmt.executeBatch();
                }
                conn.commit();
            } else {
                conn.rollback();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        return orderId;
    }
}