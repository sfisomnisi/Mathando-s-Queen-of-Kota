package za.ac.tut.kotashop.dao;

import za.ac.tut.kotashop.model.ContactMessage;
import java.sql.*;

public class ContactDAO {
    
    public boolean saveContactMessage(ContactMessage message) {
        String sql = "INSERT INTO contact_messages (name, email, phone, subject, message, message_type) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, message.getName());
            pstmt.setString(2, message.getEmail());
            pstmt.setString(3, message.getPhone());
            pstmt.setString(4, message.getSubject());
            pstmt.setString(5, message.getMessage());
            pstmt.setString(6, message.getMessageType());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}