package za.ac.tut.kotashop.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.kotashop.model.CartItem;
import za.ac.tut.kotashop.model.Product;

public class SaveCartToSessionServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String cartData = request.getParameter("cartData");
        System.out.println("SaveCartToSessionServlet - Cart Data: " + cartData);
        
        List<CartItem> cart = new ArrayList<CartItem>();
        
        if (cartData != null && !cartData.isEmpty()) {
            try {
                String clean = cartData.substring(1, cartData.length() - 1);
                String[] items = clean.split("\\},\\{");
                
                for (String itemStr : items) {
                    String cleanItem = itemStr.replace("{", "").replace("}", "");
                    String[] fields = cleanItem.split(",");
                    
                    int id = 0;
                    String name = "";
                    double price = 0;
                    int quantity = 0;
                    
                    for (String field : fields) {
                        if (field.contains("\"id\"")) {
                            String val = field.substring(field.indexOf(":") + 1);
                            id = Integer.parseInt(val.trim());
                        } else if (field.contains("\"name\"")) {
                            name = field.substring(field.indexOf("\"") + 1, field.lastIndexOf("\""));
                        } else if (field.contains("\"price\"")) {
                            String val = field.substring(field.indexOf(":") + 1);
                            price = Double.parseDouble(val.trim());
                        } else if (field.contains("\"quantity\"")) {
                            String val = field.substring(field.indexOf(":") + 1);
                            quantity = Integer.parseInt(val.trim());
                        }
                    }
                    
                    if (!name.isEmpty() && quantity > 0) {
                        Product product = new Product();
                        product.setProductId(id);
                        product.setProductName(name);
                        product.setPrice(price);
                        CartItem cartItem = new CartItem(product, quantity);
                        cart.add(cartItem);
                    }
                }
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
        
        HttpSession session = request.getSession();
        session.setAttribute("cart", cart);
        System.out.println("Saved " + cart.size() + " items to session");
        
        response.sendRedirect(request.getContextPath() + "/pages/checkout.jsp");
    }
}