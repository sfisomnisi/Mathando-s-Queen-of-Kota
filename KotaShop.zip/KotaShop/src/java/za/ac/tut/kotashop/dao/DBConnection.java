package za.ac.tut.kotashop.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    // For Derby (NetBeans default)
    private static final String DB_URL = "jdbc:derby://localhost:1527/kotashop_db;create=true";
    private static final String USER = "app";
    private static final String PASSWORD = "app";
    
    static {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            System.out.println("Derby JDBC Driver loaded successfully");
        } catch (ClassNotFoundException e) {
            System.err.println("Derby JDBC Driver not found!");
            e.printStackTrace();
        }
    }
    
    public static Connection getConnection() throws SQLException {
        System.out.println("Attempting to connect to database...");
        Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
        System.out.println("Database connected successfully!");
        return conn;
    }
    
    // Test connection method
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null;
        } catch (SQLException e) {
            System.err.println("Connection test failed: " + e.getMessage());
            return false;
        }
    }
}