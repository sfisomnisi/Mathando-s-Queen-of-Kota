package za.ac.tut.kotashop.servlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.kotashop.model.CartItem;

public class ProcessOrderServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String instructions = request.getParameter("instructions");
        String paymentMethod = request.getParameter("paymentMethod");
        
        HttpSession session = request.getSession();
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        
        double subtotal = 0;
        if (cart != null) {
            for (CartItem item : cart) {
                subtotal += item.getSubtotal();
            }
        }
        
        String orderNumber = generateOrderNumber();
        String dateTime = new java.text.SimpleDateFormat("EEEE, MMMM dd, yyyy 'at' HH:mm:ss")
            .format(new java.util.Date());
        
        request.setAttribute("orderNumber", orderNumber);
        request.setAttribute("dateTime", dateTime);
        request.setAttribute("customerName", fullName);
        request.setAttribute("customerEmail", email);
        request.setAttribute("customerPhone", phone);
        request.setAttribute("deliveryAddress", address);
        request.setAttribute("specialInstructions", instructions);
        request.setAttribute("paymentMethod", paymentMethod);
        request.setAttribute("cart", cart);
        request.setAttribute("subtotal", subtotal);
        
        session.removeAttribute("cart");
        
        request.getRequestDispatcher("/pages/order-receipt.jsp").forward(request, response);
    }
    
    private String generateOrderNumber() {
        java.util.Date d = new java.util.Date();
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss");
        String random = java.util.UUID.randomUUID().toString().substring(0, 4).toUpperCase();
        return "ORD-" + sdf.format(d) + "-" + random;
    }
}