package za.ac.tut.kotashop.dao;

import za.ac.tut.kotashop.model.Rating;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RatingDAO {
    
    public boolean saveRating(Rating rating) {
        String sql = "INSERT INTO ratings (product_id, customer_name, customer_email, rating_value, review_text) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setObject(1, rating.getProductId());
            pstmt.setString(2, rating.getCustomerName());
            pstmt.setString(3, rating.getCustomerEmail());
            pstmt.setInt(4, rating.getRatingValue());
            pstmt.setString(5, rating.getReviewText());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public double getAverageRatingForProduct(int productId) {
        String sql = "SELECT AVG(rating_value) as avg_rating FROM ratings WHERE product_id = ? AND is_approved = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getDouble("avg_rating");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public List<Rating> getApprovedRatingsForProduct(int productId, int limit) {
        List<Rating> ratings = new ArrayList<>();
        String sql = "SELECT * FROM ratings WHERE product_id = ? AND is_approved = TRUE ORDER BY created_at DESC LIMIT ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, productId);
            pstmt.setInt(2, limit);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Rating r = new Rating();
                r.setRatingId(rs.getInt("rating_id"));
                r.setProductId(rs.getInt("product_id"));
                r.setCustomerName(rs.getString("customer_name"));
                r.setRatingValue(rs.getInt("rating_value"));
                r.setReviewText(rs.getString("review_text"));
                r.setCreatedAt(rs.getTimestamp("created_at"));
                ratings.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ratings;
    }
}