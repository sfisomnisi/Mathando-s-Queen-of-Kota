package za.ac.tut.kotashop.servlets;

import za.ac.tut.kotashop.dao.OrderDAO;
import za.ac.tut.kotashop.model.CartItem;
import za.ac.tut.kotashop.model.Order;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class OrderServlet extends HttpServlet {
    private OrderDAO orderDAO = new OrderDAO();
    
    @Override
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        
        if (cart == null || cart.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/pages/cart.jsp");
            return;
        }
        
        String customerName = request.getParameter("customerName");
        String customerEmail = request.getParameter("customerEmail");
        String customerPhone = request.getParameter("customerPhone");
        String deliveryAddress = request.getParameter("deliveryAddress");
        String specialInstructions = request.getParameter("specialInstructions");
        String paymentMethod = request.getParameter("paymentMethod");
        
        double subtotal = 0;
        for (CartItem item : cart) {
            subtotal += item.getSubtotal();
        }
        double deliveryFee = subtotal >= 150 ? 0 : 30;
        double totalAmount = subtotal + deliveryFee;
        
        Order order = new Order();
        order.setCustomerName(customerName);
        order.setCustomerEmail(customerEmail);
        order.setCustomerPhone(customerPhone);
        order.setDeliveryAddress(deliveryAddress);
        order.setSpecialInstructions(specialInstructions);
        order.setSubtotal(subtotal);
        order.setDeliveryFee(deliveryFee);
        order.setTotalAmount(totalAmount);
        order.setPaymentMethod(paymentMethod);
        
        int orderId = orderDAO.saveOrder(order, cart);
        
        if (orderId > 0) {
            session.removeAttribute("cart");
            request.setAttribute("orderNumber", order.getOrderNumber());
            request.setAttribute("totalAmount", totalAmount);
            request.getRequestDispatcher("/pages/order-success.jsp").forward(request, response);
        } else {
            request.setAttribute("error", "Failed to place order. Please try again.");
            request.getRequestDispatcher("/pages/checkout.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/pages/cart.jsp");
    }
}