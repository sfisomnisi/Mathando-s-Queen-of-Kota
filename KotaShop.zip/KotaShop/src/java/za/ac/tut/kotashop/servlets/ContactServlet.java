package za.ac.tut.kotashop.servlets;

import za.ac.tut.kotashop.dao.ContactDAO;
import za.ac.tut.kotashop.model.ContactMessage;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ContactServlet extends HttpServlet {
    private ContactDAO contactDAO = new ContactDAO();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String subject = request.getParameter("subject");
        String message = request.getParameter("message");
        String messageType = request.getParameter("messageType");
        
        ContactMessage contactMessage = new ContactMessage();
        contactMessage.setName(name);
        contactMessage.setEmail(email);
        contactMessage.setPhone(phone);
        contactMessage.setSubject(subject);
        contactMessage.setMessage(message);
        contactMessage.setMessageType(messageType);
        
        boolean saved = contactDAO.saveContactMessage(contactMessage);
        
        if (saved) {
            request.setAttribute("success", "Thank you! Your message has been sent. We'll get back to you soon.");
        } else {
            request.setAttribute("error", "Failed to send message. Please try again.");
        }
        
        request.getRequestDispatcher("/pages/contact.jsp").forward(request, response);
    }
}